//
//  PatchApiSDK.h
//  PatchApiSDK
//
//  Created by Ivanov Developer on 6/4/18.
//  Copyright © 2018 Anna Hornung. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PatchApiSDK.
FOUNDATION_EXPORT double PatchApiSDKVersionNumber;

//! Project version string for PatchApiSDK.
FOUNDATION_EXPORT const unsigned char PatchApiSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PatchApiSDK/PublicHeader.h>


